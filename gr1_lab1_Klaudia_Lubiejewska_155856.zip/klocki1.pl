% PROGRAM: klocki_1
% Baza wiedzy o uk�adzie klock�w
% Definiowane predykaty:
% na/2
% ======================================================


% na(X,Y)
% opis: spe�niony, gdy klocek x
% le�y bezpo�rednio na klocku Y
% --------------------------------------------------na/2
na(c,a).
na(c,b).
na(d,c).
% --------------------------------------------------na/2

/*
Informacje o budowie programu:
Program sk�ada si� z 3 klauzul.
Program zawiera 1 definicj� relacji.
Jest to relacja na/2.
Definicja relacji na/2 sk�ada si� z
3 klauzul,kt�re s� faktami.
*/
